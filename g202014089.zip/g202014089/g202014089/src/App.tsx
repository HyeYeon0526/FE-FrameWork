import React from 'react';
import TodoRoot from './TodoRoot';


function App() {
  return (
    <TodoRoot />
  );
}

export default App;
