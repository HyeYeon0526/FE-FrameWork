function sum(...args) {
    let result += args;
}

console.log(sum(3, 4, 5)); 

console.log(sum(3, 4, 5, 6));