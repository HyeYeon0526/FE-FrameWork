function add (a,b) {
    return a + b;
}

function multiply (a,b) {
    return a * b; 
}

export {add, multiply}; 