import { add, multiply } from './exam5_module.js'; 

console.log(add(3, 4)); 
console.log(multiply(3, 4));