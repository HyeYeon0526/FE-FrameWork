function toArray(...args) {
    
}


console.log(toArray(0, 1, 2, 3));
console.log(toArray(5, 8, 9)); 
console.log(toArray(7, 6)); 
console.log(toArray(4));