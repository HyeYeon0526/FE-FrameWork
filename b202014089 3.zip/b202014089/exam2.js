let a = [1, 2, 3, 4];

// 자리 이동 구현

let [x,y,z,k] = a;

a = [k, x, y, z];

console.log(a);